﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using theWall.Models;

namespace theWall.Controllers
{
    public class HomeController : Controller
    {
        [HttpGet]
        [Route("")]
        public IActionResult Index()
        {
            if(HttpContext.Session.GetString("name") == null)
            {
                return View();
            }
            else 
            {
                return RedirectToAction("Success", "Wall");
            }
        }

        [HttpGet]
        [Route("login")]
        public IActionResult Login()
        {
            return View("Login");
        }

        [HttpGet]
        [Route("logout")]
        public IActionResult Logout()
        {
            HttpContext.Session.Clear();
            return RedirectToAction("Index");
        }

        [HttpPost]
        [Route("Wall")]
        public IActionResult Logged()
        {
            return View("Wall");
        }
     
        
        [HttpPost] // A post request
        [Route("Register")] //The route register

        public IActionResult Register(RegUser newUser) 
        {

	        if(ModelState.IsValid)
	    {
            string checkEmail = $"SELECT * FROM users WHERE(email = '{newUser.Email}')";
            var exists = DbConnector(checkEmail);
            if(exists.Count > 0)
            {
                ViewBag.Email = "This email is already in use!";
                
                return View("Index");
            }

	        }
	        else
	        {
	            string query = $"INSERT INTO theWall (FirstName, LastName, Password, Email) VALUES ('{newUser.FirstName}', '{newUser.LastName}', '{newUser.Password}','{newUser.Email}')";
                System.Console.WriteLine(query);
	            DbConnector.Execute(query);
                HttpContext.Session.SetString("user", newUser.FirstName);
                var qSession = DbConnector(checkEmail);
                int sessionID = (int)qSession[0]["id"];

		        return RedirectToAction("Success", "Wall");
	}


}


        [HttpPost]
        [Route("login")]
        public IActionResult Login(LoginUser model)
        {
            if (ModelState.IsValid)
            {
                string query = $"SELECT * FROM users WHERE(email = '{model.user_id.Email}');";  //what do I need to replace user_id with?
                var exists = DbConnector.Query(query);
                if(exists.Count == 0)
                {
                    ViewBag.Email = "Email does not exist!";
                    return View("Index");
                }
                else
                {
                    string pass = (exists[0]["password"]).ToString();
                    if(pass !=  model.user_id.Password)
                    {
                        ViewBag.password = "Wrong Password!";
                        return View("Index");
                    }
                    else
                    {
                    int id = (int)exists[0]["id"];
                    HttpContext.Session.SetInt32("id", id);
                    string firstName = (exists[0]["firstName"]).ToString();
                    string lastName = (exists[0]["lastName"]).ToString();
                    string name = firstName + " " + lastName;
                    HttpContext.Session.SetString("name", name);
                    TempData["name"] = HttpContext.Session.GetString("name");
                    
                    return RedirectToAction("Success", "Wall");

                }
            }
        }
        else 
        {
            return View("Index");
        }

//         if(TryValidateModel(NewUser) == false){

//         ViewBag.errors = ModelState.Values;
//         return View("Error");
//         }
//         else{

//         return View("formPage");
//         }
//  }
//         public IActionResult Error()
//         {
//             return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
//         }
//     }
}
}
}